<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
     <!-- Bootstrap CSS -->
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-0F3P3LF170"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-0F3P3LF170');
</script>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>
</head>
<body>


    
    <div id="resultDiv">
        
    </div>

 <input type="text" id="ahmed">
   <script type="module" >



            var pusher = new Pusher('b2636ae7a9413d9bf90b', {
                cluster: 'ap2'
                });
                // Subscribe to the dynamic channel
                var channel = pusher.subscribe('recommendation.AdviceVIP');
                console.log(channel);
                // Listen for events on the channel
                channel.bind('recommendation.AdviceVIP', function (data) {
                console.log('Received recommendation event:', data);
                // Handle the received event data here

                });

                var channel = pusher.subscribe('chat.AdviceVIP');
                // console.log(channel);
                // Listen for events on the channel
                channel.bind('chat.AdviceVIP', function (data) {
                console.log('Received recommendation event:', data);
                // Handle the received event data here
                });


         var channel = pusher.subscribe('closeChat.Diamond');
                // console.log(channel);
                // Listen for events on the channel
                channel.bind('closeChat.Diamond', function (data) {
                console.log('Received recommendation event:', data);
                // Handle the received event data here
                });






// var x="plan1";
// // console.log('recommendation/'+x);
//     window.Echo.channel('recommendation')
//     .listen('.recommendation/'+x,(e)=>{
//        console.log(e);
//     });

// //chat

//     window.Echo.channel('ChatPlan')
//     .listen('.ChatPlan',(e)=>{
// console.log(e);
//         var result = e.Massage.original.massage.massage;
//         var resultText = document.createTextNode(result);

//         var resultDiv = document.getElementById("resultDiv");
//        resultDiv.appendChild(resultText);
//     });




  </script>

<video src=""></video>

<img src="<?php echo e(asset('media/1687005572_c8d59d95fee45f25efe21d7bd03d5e70.mp4')); ?>" alt="">


</body>
</html>



<?php /**PATH /home/gfoura/public_html/dev.gfoura.smartidea.tech/resources/views/welcome.blade.php ENDPATH**/ ?>